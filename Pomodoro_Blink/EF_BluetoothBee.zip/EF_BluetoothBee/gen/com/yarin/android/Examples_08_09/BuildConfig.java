/** Automatically generated file. DO NOT MODIFY */
package com.yarin.android.Examples_08_09;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}